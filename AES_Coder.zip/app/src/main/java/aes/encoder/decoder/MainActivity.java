package aes.encoder.decoder;

import aes.encoder.decoder.databinding.*;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private MainBinding binding;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		binding.button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try {
					android.widget.EditText edittext1 =
					(android.widget.EditText) findViewById(
					getResources().getIdentifier(
					"edittext1",
					"id",
					getPackageName()
					)
					);
					
					android.widget.EditText edittext3 =
					(android.widget.EditText) findViewById(
					getResources().getIdentifier(
					"edittext3",
					"id",
					getPackageName()
					)
					);
					
					android.widget.TextView textview1 =
					(android.widget.TextView) findViewById(
					getResources().getIdentifier(
					"textview1",
					"id",
					getPackageName()
					)
					);
					
					
					// Generate AES key
					javax.crypto.KeyGenerator keyGenerator =
					javax.crypto.KeyGenerator.getInstance("AES");
					
					keyGenerator.init(256);
					
					javax.crypto.SecretKey secretKey =
					keyGenerator.generateKey();
					
					
					// Convert key to Base64
					String keyBase64 =
					android.util.Base64.encodeToString(
					secretKey.getEncoded(),
					android.util.Base64.NO_WRAP
					);
					
					
					// Display key
					edittext3.setText(keyBase64);
					
					
					// Get text
					String text =
					edittext1.getText().toString();
					
					
					// Encrypt
					javax.crypto.Cipher cipher =
					javax.crypto.Cipher.getInstance(
					"AES/ECB/PKCS5Padding"
					);
					
					cipher.init(
					javax.crypto.Cipher.ENCRYPT_MODE,
					secretKey
					);
					
					byte[] encrypted =
					cipher.doFinal(
					text.getBytes("UTF-8")
					);
					
					
					// Convert encrypted data to Base64
					String output =
					android.util.Base64.encodeToString(
					encrypted,
					android.util.Base64.NO_WRAP
					);
					
					
					// Display encrypted text
					textview1.setText(output);
					
					
				} catch (Exception e) {
					
					android.widget.Toast.makeText(
					getApplicationContext(),
					e.toString(),
					android.widget.Toast.LENGTH_LONG
					).show();
					
				}
			}
		});
		
		binding.button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try {
					android.widget.EditText edittext1 =
					(android.widget.EditText) findViewById(
					getResources().getIdentifier(
					"edittext1",
					"id",
					getPackageName()
					)
					);
					
					android.widget.EditText edittext5 =
					(android.widget.EditText) findViewById(
					getResources().getIdentifier(
					"edittext5",
					"id",
					getPackageName()
					)
					);
					
					android.widget.TextView textview1 =
					(android.widget.TextView) findViewById(
					getResources().getIdentifier(
					"textview1",
					"id",
					getPackageName()
					)
					);
					
					
					// Get text
					String text =
					edittext1.getText().toString();
					
					
					// Get key
					String keyBase64 =
					edittext5.getText().toString();
					
					
					// Decode Base64 key
					byte[] keyBytes =
					android.util.Base64.decode(
					keyBase64,
					android.util.Base64.DEFAULT
					);
					
					
					// Create AES key
					javax.crypto.spec.SecretKeySpec secretKey =
					new javax.crypto.spec.SecretKeySpec(
					keyBytes,
					"AES"
					);
					
					
					// Create AES cipher
					javax.crypto.Cipher cipher =
					javax.crypto.Cipher.getInstance(
					"AES/ECB/PKCS5Padding"
					);
					
					
					// Encrypt mode
					cipher.init(
					javax.crypto.Cipher.ENCRYPT_MODE,
					secretKey
					);
					
					
					// Encrypt
					byte[] encrypted =
					cipher.doFinal(
					text.getBytes("UTF-8")
					);
					
					
					// Convert to Base64
					String output =
					android.util.Base64.encodeToString(
					encrypted,
					android.util.Base64.NO_WRAP
					);
					
					
					// Display output
					textview1.setText(output);
					
					
				} catch (Exception e) {
					
					android.widget.Toast.makeText(
					getApplicationContext(),
					e.toString(),
					android.widget.Toast.LENGTH_LONG
					).show();
					
				}
			}
		});
		
		binding.button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try {
					android.widget.EditText edittext1 =
					(android.widget.EditText) findViewById(
					getResources().getIdentifier(
					"edittext1",
					"id",
					getPackageName()
					)
					);
					
					android.widget.EditText edittext5 =
					(android.widget.EditText) findViewById(
					getResources().getIdentifier(
					"edittext5",
					"id",
					getPackageName()
					)
					);
					
					android.widget.TextView textview1 =
					(android.widget.TextView) findViewById(
					getResources().getIdentifier(
					"textview1",
					"id",
					getPackageName()
					)
					);
					
					
					// Get encrypted text
					String encryptedBase64 =
					edittext1.getText().toString();
					
					
					// Get key
					String keyBase64 =
					edittext5.getText().toString();
					
					
					// Decode key
					byte[] keyBytes =
					android.util.Base64.decode(
					keyBase64,
					android.util.Base64.DEFAULT
					);
					
					
					// Create AES key
					javax.crypto.spec.SecretKeySpec secretKey =
					new javax.crypto.spec.SecretKeySpec(
					keyBytes,
					"AES"
					);
					
					
					// Decode encrypted Base64
					byte[] encryptedBytes =
					android.util.Base64.decode(
					encryptedBase64,
					android.util.Base64.DEFAULT
					);
					
					
					// Create cipher
					javax.crypto.Cipher cipher =
					javax.crypto.Cipher.getInstance(
					"AES/ECB/PKCS5Padding"
					);
					
					
					// Decrypt mode
					cipher.init(
					javax.crypto.Cipher.DECRYPT_MODE,
					secretKey
					);
					
					
					// Decrypt
					byte[] decrypted =
					cipher.doFinal(encryptedBytes);
					
					
					// Convert to text
					String output =
					new String(
					decrypted,
					"UTF-8"
					);
					
					
					// Display result
					textview1.setText(output);
					
					
				} catch (Exception e) {
					
					android.widget.Toast.makeText(
					getApplicationContext(),
					e.toString(),
					android.widget.Toast.LENGTH_LONG
					).show();
					
				}
			}
		});
		
		binding.button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try {
					android.widget.TextView textview1 =
					(android.widget.TextView) findViewById(
					getResources().getIdentifier(
					"textview1",
					"id",
					getPackageName()
					)
					);
					
					android.content.ClipboardManager clipboard =
					(android.content.ClipboardManager)
					getSystemService(CLIPBOARD_SERVICE);
					
					android.content.ClipData clip =
					android.content.ClipData.newPlainText(
					"Copied Text",
					textview1.getText().toString()
					);
					
					clipboard.setPrimaryClip(clip);
					
					android.widget.Toast.makeText(
					getApplicationContext(),
					"Copied!",
					android.widget.Toast.LENGTH_SHORT
					).show();
					
				} catch (Exception e) {
					
					android.widget.Toast.makeText(
					getApplicationContext(),
					e.toString(),
					android.widget.Toast.LENGTH_LONG
					).show();
					
				}
			}
		});
	}
	
	private void initializeLogic() {
	}
	
}